from segio_archive.__main__ import main

if __name__ == "__main__":
    raise SystemExit(main())
