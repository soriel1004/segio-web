# 개인 SEGIO 로그인으로 자료 받기 · v0.5.0

개인 SEGIO 직원 아이디·암호로 본인의 결재 문서와 메일을 폴더에 보관합니다. [v0.5.0 소스 ZIP 다운로드](https://github.com/soriel1004/segio-web/raw/refs/heads/main/downloads/segio-web-0.5.0.zip) 후 Windows에 Python 3.12를 설치하고 `run_windows.bat`을 실행합니다. 창의 **v0.5.0**을 확인하세요. Windows 실행 파일은 [이 저장소의 Actions](https://github.com/soriel1004/segio-web/actions)에서 해당 버전의 성공한 빌드가 있는지 확인한 뒤 받습니다. 기존 `segio` 저장소의 SSH 전용 실행 파일은 별도 프로그램입니다.

프로그램 배포 ZIP 파일명은 `segio-web-{프로그램 버전}.zip` 형식입니다. 현재 버전은 `segio-web-0.5.0.zip`이며, Windows 빌드도 프로그램의 버전 번호를 읽어 같은 이름으로 저장합니다.

첫 화면은 **결재 문서·메일·암호화되지 않은 HTTP 연결 허용**만 기본 선택합니다. HTTPS 주소에서는 인증서 검증을 유지합니다. 개인 로그인 방식은 [서버 연결 기능](docs/WINDOWS_LOGIN.md)이 설치되어 있어야 하며, 서버에는 전송·검증용 임시 ZIP이 필요합니다. 내려받은 뒤 다시 ZIP을 만들거나 최종 ZIP을 추가 저장하지 않고 **백업 폴더만** 남깁니다. SSH 방식의 추가 ZIP도 기본 해제입니다.

## 백업 폴더의 index.html

- **메일:** 받은편지함·보낸편지함과 원래 사용자 지정 보관함을 상단 메뉴로 선택합니다. 파일·보관함 이름으로 분류하고 발신 주소로 추정하지 않습니다.
- **날짜:** 제목 옆에 원본 메일의 `Date` 헤더 날짜·시간대를 표시하고, 시간대를 확인할 수 있는 날짜를 최신순으로 정렬합니다. 이동·다운로드·백업 시각으로 대체하지 않습니다. 없는 날짜는 `날짜 미상`입니다.
- **결재:** 완료문서·반려문서·참조문서·수신문서·진행문서·임시문서·상태 미확인을 상단 메뉴로 선택합니다. 참조·수신 관계는 상태와 중복될 수 있습니다. 뜻이 확인되지 않은 숫자 상태 코드는 임의로 완료·반려로 분류하지 않습니다.
- 검색·건수·100건 단위 페이지 이동은 선택한 분류에 적용됩니다. 백업 폴더 전체를 유지하면 서버와 연결하지 않고 사용할 수 있습니다.

**기존 백업은 새 프로그램의 ‘기존 백업 갱신’ 또는 ‘보관함 열기’에서 폴더를 선택하세요.** 이미 받은 원본·첨부·SQLite를 유지하면서 인덱스를 갱신합니다. 서버에서 다시 다운로드할 필요는 없습니다. 기존에 따로 만든 ZIP은 갱신하지 않습니다.

두 프로그램의 서버 도구는 [공용 tools 안내](tools/README.md)를 참고하세요. 아래는 기존 관리자 SSH 방식의 상세 안내입니다.

## 다른 수집 방식과 보관 범위

가져오기 방식에서 관리자 SSH 백업 또는 웹 화면 수집도 선택할 수 있습니다. SSH 암호와 직원 SEGIO 암호는 서로 다른 입력이며, [SSH 사용 안내](docs/SSH_ARCHIVE.md)와 [개인 로그인 연결 안내](docs/WINDOWS_LOGIN.md)를 참고하세요. 개인 DB·MBOX 방식은 로그인한 직원의 관계로 연결되는 결재와 본인 메일을 가져옵니다. 전체 서버 DB 복제나 원래 SEGIO 화면별 권한과 동일하다고 검증한 기능은 아닙니다. 암호·쿠키는 백업이나 설정에 저장하지 않습니다.

폴더의 `index.html`, `search`, `documents`, `mail`, `catalog.sqlite3`, `manifest.json`을 함께 보관하세요. 원본 MBOX와 첨부를 보존하며 서버의 계정이나 자료를 삭제하지 않습니다.

## 개발·검증

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m playwright install chromium
SEGIO_TEST_PHP=php .venv/bin/python tools/run_ci_tests.py
```

기존 Chromium을 쓰는 경우 `SEGIO_TEST_BROWSER`에 실행 파일 경로를 지정합니다. Windows 패키지는 Windows에서 `build_windows.ps1`로 빌드합니다. 이번 검사 결과와 운영 서버·Windows 현장 확인 범위는 [VALIDATION.md](VALIDATION.md)를 참고하세요.
